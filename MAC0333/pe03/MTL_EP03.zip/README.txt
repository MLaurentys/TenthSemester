Olá professor,

Existem alguma diferenças comparados à especificação, porém acredito não serem muito importantes. Todas as diferenças que encontrei estão listadas a seguir.

- Quando se usam as opções -o3 e -o4, ao invés de imprimir o comprimento do intervalo ao lado no índice do documento, eu imprimo o intervalo em si. Seria fácil mudar porém exigiria verificar o caso de ordenação e, então modificar o valor da impressão. Prefiri tratar como o caso geral para evitar emaranhamento no código. Entendo que com mudança mais drástica poderia evitar complicação nessa parte mas não julguei necessário.

- Eu não criei arquivos separados para os índices posicionais. O índice está sendo mandados junto com o índice invertido, com a lista de arquivos e afins. Isso seria outra mudança, não tão simples porém fácil de fazer. Tomei essa decisão para facilitar minha vida, pois estou bem apertado com o fim do semestre. Entendo que isso é problemático, mas espero que não prejudique tanto.

Muito obrigado pelo semestre e boas férias!
Matheus T. de Laurentys
